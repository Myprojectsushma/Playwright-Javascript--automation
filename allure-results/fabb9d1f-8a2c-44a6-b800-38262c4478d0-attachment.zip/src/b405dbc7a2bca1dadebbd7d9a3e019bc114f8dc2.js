import{test, expect} from "@playwright/test"
test("homepage", async({page})=>{

await page.goto("https://demoblaze.com/")
const pagetitle = page.title();
console.log('page title is:', pagetitle)
await expect(page).toHaveTitle("store");

})